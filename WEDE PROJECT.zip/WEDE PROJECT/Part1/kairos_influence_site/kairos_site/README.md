# Kairos Influence — Website Project (WEDE5020 PoE)

## Project Title
Kairos Influence — Cape Town Streetwear Boutique Website

## Student Information
- **Name:** Bandile Mngomezulu
- **Student Number:** 10518101
- **Module:** WEDE5020 — Web Development: Introduction
- **Group:** GR01

## Project Overview
Kairos Influence is an independent streetwear boutique based in Observatory, Cape Town, founded in 2022.
This project is the design and development of a professional, responsive, SEO-optimised website for
the brand, built in three parts across the semester:

- **Part 1:** HTML foundation — structure, content, navigation, and project planning.
- **Part 2:** CSS styling — brand identity, responsive layout, and visual design.
- **Part 3:** JavaScript functionality and SEO optimisation.

## Website Goals and Objectives
- Convert Kairos Influence's existing Instagram/WhatsApp following into a reliable online sales channel.
- Grow monthly website traffic and newsletter sign-ups.
- Provide a professional, mobile-first shopping experience.

**Key Performance Indicators (KPIs):**
- Monthly unique visitors and returning visitor rate.
- Online enquiry-to-sale conversion rate.
- Average session duration and bounce rate.
- Newsletter sign-up rate per visitor.

## Key Features and Functionality
- Five-page structure: Home, About Us, Shop, Enquiry, Contact Us.
- Product catalogue with sizing details.
- Product enquiry form (item, size, quantity).
- Contact form and two embedded store/stockist locations.
- Fully responsive, mobile-first layout (styling completed in Part 2).

## Timeline and Milestones
| Milestone | Deliverable                                  | Target Date            |
|-----------|-----------------------------------------------|-------------------------|
| Part 1    | Project proposal, HTML structure, GitHub setup | Part 1 submission date |
| Part 2    | CSS styling, responsive layout                 | Part 2 submission date |
| Part 3    | JavaScript functionality, SEO optimisation     | Part 3 submission date |

## Part 1 Details
Part 1 covers the foundational build of the site:
- Two Website Project Proposals submitted and presented for lecturer approval — **Kairos Influence**
  (streetwear boutique, approved direction) and **Jesus is King Animal Sanctuary** (non-profit, backup).
- Content research and sourcing for the Kairos Influence site.
- Semantic HTML5 structure for all five pages (`header`, `nav`, `main`, `footer`, `article`, `section`).
- Organised file and folder structure (`css/`, `js/`, `images/`, `_private/`).
- Functional navigation linking all five pages.
- Initial commit and push to the private GitHub repository.

*(Part 2 and Part 3 details will be added to this README in future submissions/edits.)*

## Sitemap
```
index.html (Home)
├── about.html (About Us)
├── products.html (Shop)
├── enquiry.html (Enquiry)
└── contact.html (Contact Us)
```
See `sitemap.png` in the repository root for the visual sitemap diagram.

## File and Folder Structure
```
/
├── index.html
├── about.html
├── products.html
├── enquiry.html
├── contact.html
├── sitemap.png
├── css/
│   └── style.css
├── js/
├── images/
│   ├── hero-banner.jpg
│   ├── logo.png
│   ├── about-team.jpg
│   └── product-1.jpg ... product-6.jpg
└── _private/
```

## Changelog
| Date       | Change                                                                 |
|------------|-------------------------------------------------------------------------|
| 2026-08-04 | Initial repository setup — file/folder structure created.              |
| 2026-08-04 | Built semantic HTML5 structure for all 5 pages (index, about, products, enquiry, contact). |
| 2026-08-04 | Added base CSS for structural readability (full styling in Part 2).    |
| 2026-08-04 | Added sitemap diagram and README documentation.                        |
| 2026-08-05 | Added real hero banner image (AI-generated via ChatGPT) to homepage.   |
| 2026-08-05 | Added 3 real product photos (Sanctified Cross Tee, Kairos Zip Hoodie, Kairos Cross Joggers); remaining shop slots marked "Coming Soon". |
| 2026-08-05 | Created gothic wordmark logo using UnifrakturMaguntia typeface, matching embroidered "K" branding on garments. |
| 2026-08-05 | Added real crew photo to About Us page; updated team section copy to match. |

## References
Referencing style: **Harvard (IIE-adapted)**.

- Afrihost, 2026. *Shared Hosting*. [online] Available at: <https://www.afrihost.com/shared-hosting> [Accessed 4 August 2026].
- Krug, S., 2014. *Don't Make Me Think, Revisited: A Common Sense Approach to Web Usability*. 3rd ed. Berkeley: New Riders.
- OpenAI, 2026. *ChatGPT* (image generation feature). [AI tool] Available at: <https://chatgpt.com> [Accessed 5 August 2026]. Used to generate the homepage hero banner image (`images/hero-banner.jpg`).
- Unifraktur Project, 2017. *UnifrakturMaguntia* (typeface). [online] Available at: <https://github.com/google/fonts/tree/main/ofl/unifrakturmaguntia> [Accessed 5 August 2026]. SIL Open Font License. Used for the "Kairos" wordmark logo (`images/logo.png`).
- W3Schools, 2026. *HTML5 Semantic Elements*. [online] Available at: <https://www.w3schools.com/html/html5_semantic_elements.asp> [Accessed 4 August 2026].

*Additional references specific to the Website Project Proposal document appear in that file's own reference list.*
*Note: Use of ChatGPT for image generation and of Claude for development assistance will be documented in full in the AI Disclosure Annexe accompanying this submission, per IIE guidelines.*
